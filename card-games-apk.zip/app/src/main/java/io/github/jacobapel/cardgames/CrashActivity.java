package io.github.jacobapel.cardgames;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ScrollView;
import android.widget.TextView;

public class CrashActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String trace = getSharedPreferences("crash", MODE_PRIVATE)
                .getString("trace", "No crash report saved. Open the card games app first, then open this screen again.");
        TextView view = new TextView(this);
        view.setText(trace);
        view.setTextIsSelectable(true);
        view.setTextSize(12);
        view.setPadding(32, 120, 32, 32);
        ScrollView scroll = new ScrollView(this);
        scroll.addView(view);
        setContentView(scroll);
    }
}
