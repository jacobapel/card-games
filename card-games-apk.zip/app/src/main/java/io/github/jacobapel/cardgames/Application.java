package io.github.jacobapel.cardgames;

import android.content.SharedPreferences;
import java.io.PrintWriter;
import java.io.StringWriter;

public class Application extends android.app.Application {
    @Override
    public void onCreate() {
        super.onCreate();
        final SharedPreferences prefs = getSharedPreferences("crash", MODE_PRIVATE);
        final Thread.UncaughtExceptionHandler previous = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            @Override
            public void uncaughtException(Thread thread, Throwable error) {
                StringWriter sw = new StringWriter();
                error.printStackTrace(new PrintWriter(sw));
                prefs.edit().putString("trace", "Android " + android.os.Build.VERSION.RELEASE
                        + " (SDK " + android.os.Build.VERSION.SDK_INT + ")\n\n" + sw).commit();
                if (previous != null) previous.uncaughtException(thread, error);
            }
        });
    }
}
